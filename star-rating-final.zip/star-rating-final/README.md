# Star Rating Final

A Pen created on CodePen.io. Original URL: [https://codepen.io/kin393/pen/QWBaOYP](https://codepen.io/kin393/pen/QWBaOYP).

